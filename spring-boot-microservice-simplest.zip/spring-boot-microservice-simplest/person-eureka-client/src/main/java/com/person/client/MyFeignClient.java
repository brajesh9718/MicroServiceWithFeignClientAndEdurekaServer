package com.person.client;

import java.util.ArrayList;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value="employees-service-client", url="http://localhost:3333/")
public interface MyFeignClient {
	
	@GetMapping
	String getEmployeeHello();
	
	@GetMapping("/{id}")
	String getEmloyeeById(@PathVariable int id);
	
	@GetMapping("/employeesStringList")
	ArrayList<String> getEmployeeList();
	
	@GetMapping("/employeesObjectList")
	ArrayList<EmployeeDto> getEmployeesObjectList();
	
}
