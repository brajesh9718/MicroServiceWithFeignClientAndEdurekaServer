package com.person.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@RestController
@EnableDiscoveryClient
@EnableFeignClients
public class PersonEurekaClientApplication {

	@Value("${number}")
	private String number;
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	MyFeignClient feignClient;

	public static void main(String[] args) {
		SpringApplication.run(PersonEurekaClientApplication.class, args);
	}

	@Bean
	RestTemplate resTemplate() {
		return new RestTemplate();
	}

	@RequestMapping("/")
	String getPerson() {
		return "Hello From Person Service ......";
	}

	@RequestMapping("/callemployee")
	String sayHello() {
		return "Here I am going to call Employee Microservice From Person MicroService using Feign Client ------- > "
				+ feignClient.getEmployeeHello();
	}

	@RequestMapping("/employees/{id}")
	String getEmployeeAgeById(@PathVariable int id) {
		System.out.println("Inside getEmployeeAgeById ........");
		return feignClient.getEmloyeeById(id);
	}

	@RequestMapping("/employee/{id}")
	String getHelloFromEmployee(@PathVariable int id) {
		System.out.println("Employee id is :" + id);
		Map<String, Integer> parameters = new HashMap<String, Integer>();
		parameters.put("id", id);
		String response = restTemplate.getForObject("http://localhost:3333/{id}", String.class, parameters);
		return response;
	}

	@RequestMapping("/employeesStringList")
	ArrayList<String> getEmployees() {
		return feignClient.getEmployeeList();
	}

	@GetMapping("/employeesObjectList")
	ArrayList<EmployeeDto> getEmployeesObjectList() {
		return feignClient.getEmployeesObjectList();
	}
}
